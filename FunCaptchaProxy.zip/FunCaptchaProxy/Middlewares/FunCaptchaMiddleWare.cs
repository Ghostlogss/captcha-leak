﻿using System.Net;

namespace FunCaptchaProxy.Middlewares;

public class FunCaptchaMiddleWare
{
    
    private readonly RequestDelegate _next;
    private readonly IHttpClientFactory _httpClientFactory;

    public FunCaptchaMiddleWare(RequestDelegate next, IHttpClientFactory httpClientFactory)
    {
        _next = next;
        _httpClientFactory = httpClientFactory;
    }

    public async Task Invoke(HttpContext context)
    {
        if (!context.Request.Path.Value.Contains("image"))
        {
            if (!context.Request.Path.Value.Contains("fc") && !context.Request.Path.Value.Contains("v2") ||
                context.Request.Path.Value.Contains(".js") || context.Request.Path.Value.Contains("html"))
            {
                await _next(context);
                return;
            }
        }

        var httpClient = _httpClientFactory.CreateClient("");

        Console.WriteLine(context.Request.Path.ToString());
        
        var targetUri = new UriBuilder("https://roblox-api.arkoselabs.com")
        {
            Path = context.Request.Path.ToString(),
            Query = context.Request.QueryString.ToString()
        }.Uri;
        
        var requestMessage = new HttpRequestMessage(new HttpMethod(context.Request.Method), targetUri)
        {
            Content = new StreamContent(context.Request.Body)
        };
        
        foreach (var header in context.Request.Headers)
        {
            if (header.Key != "Content-Type" && header.Key != "Content-Length" && header.Key != "Host" && header.Key != "Cookie" && header.Key != "Origin" && header.Key != "Referer")
            {
                requestMessage.Headers.TryAddWithoutValidation(header.Key, header.Value.FirstOrDefault());
            }
        }
        
        requestMessage.Headers.TryAddWithoutValidation("Referer", "https://roblox-api.arkoselabs.com/v2/2.4.5/enforcement.6c9d6e9be9aa044cc5ce9548b4abe1b0.html");
        requestMessage.Headers.TryAddWithoutValidation("Origin", "https://roblox-api.arkoselabs.com");

        if (context.Request.HasFormContentType)
        {
            var nameValueCollection =
                context.Request.Form.SelectMany(kv =>
                {
                    return kv.Value.Select(v => new KeyValuePair<string, string?>(kv.Key, (kv.Key == "site" ? "https://roblox.com" : v)));
                });
            
            var formData = new FormUrlEncodedContent(nameValueCollection);
            requestMessage.Content = formData;
        }
        
        var response = await httpClient.SendAsync(
            requestMessage);

        context.Response.StatusCode = (int)response.StatusCode;
        
        // foreach (var header in response.Headers) context.Response.Headers[header.Key] = header.Value.ToArray();
        
        foreach (var header in response.Content.Headers) context.Response.Headers[header.Key] = header.Value.ToArray();
        
        if (response.StatusCode != HttpStatusCode.NotModified) // Check if status code is 304
        {
            await response.Content.CopyToAsync(context.Response.Body);
        }
    }
}