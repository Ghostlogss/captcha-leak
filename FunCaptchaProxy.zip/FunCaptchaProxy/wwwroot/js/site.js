﻿// Function to replace hostname in URL
function replaceHostname(url) {
    console.log(url)
    return url.replace('originalhostname.com', 'newhostname.com');
}

// Proxy XMLHttpRequest
const proxiedXMLHttpRequest = new Proxy(XMLHttpRequest, {
    construct: function(target, args) {
        const xhr = new target(...args);

        // Store the original open method
        const originalOpen = xhr.open;

        // Override the open method
        xhr.open = function(method, url, async, user, password) {
            // Replace the hostname in the URL
            url = replaceHostname(url);

            // Call the original open method with modified arguments
            originalOpen.call(this, method, url, async, user, password);
        };

        // Return the proxied XMLHttpRequest object
        return xhr;
    }
});

// Replace the native XMLHttpRequest object with the proxied one
window.XMLHttpRequest = proxiedXMLHttpRequest;

// IE 11 solution instead of `URLSearchParams`.
function computeQueryParametersUsingFallback() {
    const decodedParameters = {};
    decodeURIComponent(window.location.href).replace(
        /[?&]+([^=&]+)=([^&]*)/gi,
        function (_, key, value) {
            return (decodedParameters[key] = value);
        }
    );
    return decodedParameters;
}
// const { fetch: originalFetch } = window;
//
// window.fetch = async (...args) => {
//     let [resource, config ] = args;
//
//     // request interceptor starts
//     resource = 'https://jsonplaceholder.typicode.com/todos/2';
//     // request interceptor ends
//
//     const response = await originalFetch(resource, config);
//
//     // response interceptor here
//     return response;
// };


// Get the query parameters used to set up the Arkose API:
const queryParameters =
    window.Proxy !== undefined && window.URLSearchParams !== undefined
        ? new Proxy(new URLSearchParams(window.location.search), {
            get: function (searchParameters, property) {
                return searchParameters.get(property);
            }
        })
        : computeQueryParametersUsingFallback();

// Create a script element to load the Arkose API with the passed in
// public key:
script = document.createElement('script');
script.type = 'text/javascript';
script.async = true;
script.defer = true;
const publicKey =
    queryParameters.publicKey !== undefined
        ? queryParameters.publicKey.replace(/[^a-zA-Z0-9-]+/g, '')
        : undefined;
script.src = '/js/v2/476068BF-9607-4799-B53D-966BE98E2B81/api.js';
script.setAttribute('data-callback', 'setupEnforcement');
document.getElementsByTagName('head')[0].appendChild(script);

// Setup function called by the Arkose API once it has loaded.
// Because this is an Iframe, `parent.postMessage` sends messages from the
// Arkose callbacks to the parent page, letting the parent page then
// perform the necessary actions.
function setupEnforcement(myEnforcement) {
    myEnforcement.setConfig({
        selector: '#arkose',
        mode: 'inline',
        noSuppress: queryParameters['fc_nosuppress'] == 1 ? true : false,
        data: {
            blob: decodeURIComponent(queryParameters.dataExchangeBlob)
        },
        onCompleted: function (response) {
            parent.postMessage(
                JSON.stringify({
                    arkoseIframeId: queryParameters.arkoseIframeId,
                    eventId: 'challenge-complete',
                    payload: {
                        captchaToken: response.token
                    }
                }),
                '*'
            );
        },
        onError: function (response) {
            parent.postMessage(
                JSON.stringify({
                    arkoseIframeId: queryParameters.arkoseIframeId,
                    eventId: 'challenge-error',
                    payload: {
                        captchaToken: response.token,
                        error: response.error.error
                    }
                }),
                '*'
            );
        },
        onShown: function (response) {
            parent.postMessage(
                JSON.stringify({
                    arkoseIframeId: queryParameters.arkoseIframeId,
                    eventId: 'challenge-shown',
                    payload: {
                        captchaToken: response.token
                    }
                }),
                '*'
            );
        },
        onSuppress: function (response) {
            parent.postMessage(
                JSON.stringify({
                    arkoseIframeId: queryParameters.arkoseIframeId,
                    eventId: 'challenge-suppressed',
                    payload: {
                        captchaToken: response.token
                    }
                }),
                '*'
            );
        },
        onResize: function (response) {
            parent.postMessage(
                JSON.stringify({
                    arkoseIframeId: queryParameters.arkoseIframeId,
                    eventId: 'challenge-resize',
                    payload: {
                        width: response.width,
                        height: response.height
                    }
                }),
                '*'
            );
        },
        onReady: function () {
            parent.postMessage(
                JSON.stringify({
                    arkoseIframeId: queryParameters.arkoseIframeId,
                    eventId: 'challenge-ready'
                }),
                '*'
            );
        }
    });
}
